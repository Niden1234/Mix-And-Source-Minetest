Autor: Niden And Unknown
===============================

Armor Textures: Copyright (C) 2021-2021 Niden - CC-BY-SA 3.0